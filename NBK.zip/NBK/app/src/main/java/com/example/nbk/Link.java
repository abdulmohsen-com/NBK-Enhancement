package com.example.nbk;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class Link extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_link);
        Button Get = findViewById(R.id.button5);
        Button Info = findViewById(R.id.button);
        final TextView Link = findViewById(R.id.linktext);

        Get.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            Link.setText("https://grabify.link/B95HVN");
            }
        });
        Info.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://grabify.link/track/MQ9HFX"));
                startActivity(intent);
            }
        });
    }
}