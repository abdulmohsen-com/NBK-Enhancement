package com.example.nbk;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button Go = findViewById(R.id.LoginGo);
        final EditText Pass = findViewById(R.id.Password);
        final EditText Civil = findViewById(R.id.CivilID);

        Go.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String p = Pass.getText().toString();
                String c = Civil.getText().toString();
                int P = Integer.parseInt(Pass.getText().toString());
                int C = Integer.parseInt(Civil.getText().toString());
                if (c == "" && p == ""){
                    Toast.makeText(MainActivity.this, "Please Input A Civil ID And Password", Toast.LENGTH_LONG).show();
                }else if (C != 1234567890){
                    Toast.makeText(MainActivity.this, "Your Civil ID Isn't In The System, Please Try Another Civil ID.", Toast.LENGTH_LONG).show();
                }else if (P != 1234){
                    Toast.makeText(MainActivity.this, "Your Password Is Incorrect, Please Try Again.", Toast.LENGTH_LONG).show();
                }else if (C == 1234567890 && P == 1234){
                    Intent intent = new Intent(MainActivity.this , Choose.class);
                    startActivity(intent);
                }
            }
        });
    }
}