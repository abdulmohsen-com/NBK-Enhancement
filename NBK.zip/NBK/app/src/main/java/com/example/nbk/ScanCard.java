package com.example.nbk;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import java.util.Random;

public class ScanCard extends AppCompatActivity {
    ImageView Image;
    Button Insert;

    private static final int IMAGE_PICK_CODE = 1000;
    private static final int PERMISSION_CODE = 1001;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_scan_card);
        //Views______________________________
        Insert = findViewById(R.id.insert);
        Button Scan = findViewById(R.id.Scan);
        Image = findViewById(R.id.Image);
        //____________________________________Intent__________________________________________________________________
        final String Answer[] = {
                "Yes",
                "No"
        };
        Scan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Random randomGen = new Random();
                int randomNumber = randomGen.nextInt(Answer.length);
                String Ev = Answer[randomNumber];
                if (Ev == "Yes") {
                    Intent intent = new Intent(ScanCard.this, BusinessAccount.class);
                    startActivity(intent);
                }else{
                    Intent intent = new Intent(ScanCard.this, Scanning.class);
                    startActivity(intent);
                }
            }
        });

        //Handle Button Click_______________________________________________
        Insert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Check Runtime Permission
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE)
                            == PackageManager.PERMISSION_DENIED) {
                        //Permission Not Granted, Request It.
                        String[] permissions = {Manifest.permission.READ_EXTERNAL_STORAGE};
                        //Show Popup For Runtime Permission
                        requestPermissions(permissions, PERMISSION_CODE);
                    }else{
                            //Permission Already Granted
                            pickImageFromGallery();
                        }
                    }
                else {
                    //System OS Is Less Then Marshmellow
                }

            }

        });
    }


    private void pickImageFromGallery() {
      //Intent To Pick Image
      Intent intent = new Intent(Intent.ACTION_PICK);
      intent.setType("image/*");
      startActivityForResult(intent, IMAGE_PICK_CODE);
    }
    //Handle Result Of Runtime Permission
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode) {
            case PERMISSION_CODE:{
                if (grantResults.length >0 && grantResults[0] ==
                PackageManager.PERMISSION_GRANTED) {
                    //Permission Was Granted
                    pickImageFromGallery();
                }
                else {
                    //Permission Was Denied
                    Toast.makeText(this, "Permission Denied.......", Toast.LENGTH_LONG).show();
                }
            }
        }
    }

    //Handle Result Of Pick Image

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        if (resultCode == RESULT_OK && requestCode == IMAGE_PICK_CODE) {
            // Set Image To Image View
            Image.setImageURI(data.getData());
        }
    }

}