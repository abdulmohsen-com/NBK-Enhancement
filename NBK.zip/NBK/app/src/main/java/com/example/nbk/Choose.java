package com.example.nbk;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Choose extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_choose);
        Button Move1 = findViewById(R.id.button1);
        Button Move2 = findViewById(R.id.button2);
        Button Move3 = findViewById(R.id.button3);
        Move1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Choose.this , PersonalAccount.class);
                startActivity(intent);
            }
        });
        Move2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Choose.this , BusinessAccount.class);
                startActivity(intent);
            }
        });
        Move3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Choose.this , ScanCard.class);
                startActivity(intent);
            }
        });
    }
}